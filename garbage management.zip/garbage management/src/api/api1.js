import request from '../utils/request';

export const fetchData = query => {
    return request({
        url: './ljys.json',
        method: 'get',
        params: query
    });
};
